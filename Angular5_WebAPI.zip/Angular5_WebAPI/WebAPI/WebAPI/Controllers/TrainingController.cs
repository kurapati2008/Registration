﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebAPI.Models;
using System.Data.Entity;
using System.Web.Http.Cors;

namespace WebAPI.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class TrainingController : ApiController
    {

        private DBModel db = new DBModel();

        public TrainingController()
        {
            db.Configuration.ProxyCreationEnabled = false;
        }


        // GET api/Employee
        public IQueryable<Training> GetTrainingDetails()
        {
            return db.Trainings;
        }

        // POST api/Training
        [ResponseType(typeof(Training))]
        public IHttpActionResult PostEmployee(Training training)
        {
            db.Trainings.Add(training);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = training.Id }, training);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TrainingExists(int id)
        {
            return db.Trainings.Count(e => e.Id == id) > 0;
        }
    }
}
