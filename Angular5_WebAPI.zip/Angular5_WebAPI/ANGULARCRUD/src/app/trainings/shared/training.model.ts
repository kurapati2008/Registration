export class Training {
    Id : number;
    TrainingName:string;
    StartDate:Date;
    LastDate:Date;
}
